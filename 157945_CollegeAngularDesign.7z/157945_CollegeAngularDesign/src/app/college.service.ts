import {Injectable} from '@angular/core';
import {ICollege} from './college';
import {Response} from '@angular/http';
import {Observable} from 'rxjs/Rx';
import'rxjs/add/operator/map';
import 'rxjs/add/operator/catch';
import {Http} from '@angular/http';
@Injectable()
export class CollegeService
{
    constructor(private http:Http){}
    getAllCollege():Observable<ICollege[]>
    {
          
        return this.http.get('assets/college.json').
        map((response:Response)=><ICollege[]>
        response.json());
    }
}