import { Component, OnInit } from '@angular/core';
import {ICollege} from './college';
import {CollegeService} from './college.service'
@Component({
  selector: 'clg-app',
  templateUrl: './college.component.html',
      providers:[CollegeService]
})
export class CollegeComponent  implements OnInit
{ 
    college:ICollege[];
constructor(private collegeService:CollegeService)
{
}
    ngOnInit():void
    {
        
        this.collegeService.getAllCollege().
        subscribe((clgData)=>this.college=clgData);
    }
    //sorting by collegeId
    sortById():void
    {
        this.college.sort(function(obj1,obj2)
                {
            return (obj1.collegeId<obj2.collegeId)? -1
                        : (obj1.collegeId>obj2.collegeId)?1:0;
            });
    }
    
    //sorting by collegeName
    sortByCollegeName():void
    {
        this.college.sort(function(obj1,obj2)
                {
            return (obj1.collegeName<obj2.collegeName)? -1
                        : (obj1.collegeName>obj2.collegeName)?1:0;
            });
    }
    //sorting by college State
    sortByState():void
    {
        this.college.sort(function(obj1,obj2)
                {
            return (obj1.state<obj2.state)? -1
                        : (obj1.state>obj2.state)?1:0;
            });
    }
    
     //deleting a particular row
    deleteCollege(i:number):void
    {
        this.college.splice(i, 1);
    }}
   
