import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent }  from './app.component';
import {CollegeComponent} from './college.component';
import {HttpModule} from '@angular/http'

@NgModule({
  imports:      [ BrowserModule, HttpModule ],
  declarations: [ AppComponent, CollegeComponent ],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
