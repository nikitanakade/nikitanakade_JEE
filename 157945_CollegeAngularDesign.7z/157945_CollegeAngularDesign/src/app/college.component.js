"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var college_service_1 = require("./college.service");
var CollegeComponent = (function () {
    function CollegeComponent(collegeService) {
        this.collegeService = collegeService;
    }
    CollegeComponent.prototype.ngOnInit = function () {
        var _this = this;
        this.collegeService.getAllCollege().
            subscribe(function (clgData) { return _this.college = clgData; });
    };
    //sorting by collegeId
    CollegeComponent.prototype.sortById = function () {
        this.college.sort(function (obj1, obj2) {
            return (obj1.collegeId < obj2.collegeId) ? -1
                : (obj1.collegeId > obj2.collegeId) ? 1 : 0;
        });
    };
    //sorting by collegeName
    CollegeComponent.prototype.sortByCollegeName = function () {
        this.college.sort(function (obj1, obj2) {
            return (obj1.collegeName < obj2.collegeName) ? -1
                : (obj1.collegeName > obj2.collegeName) ? 1 : 0;
        });
    };
    //sorting by college State
    CollegeComponent.prototype.sortByState = function () {
        this.college.sort(function (obj1, obj2) {
            return (obj1.state < obj2.state) ? -1
                : (obj1.state > obj2.state) ? 1 : 0;
        });
    };
    //deleting a particular row
    CollegeComponent.prototype.deleteCollege = function (i) {
        this.college.splice(i, 1);
    };
    return CollegeComponent;
}());
CollegeComponent = __decorate([
    core_1.Component({
        selector: 'clg-app',
        templateUrl: './college.component.html',
        providers: [college_service_1.CollegeService]
    }),
    __metadata("design:paramtypes", [college_service_1.CollegeService])
], CollegeComponent);
exports.CollegeComponent = CollegeComponent;
