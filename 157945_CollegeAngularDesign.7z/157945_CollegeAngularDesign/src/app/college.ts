export interface ICollege
{
    collegeId:number,
    collegeName:string,
    state:string,
    
    }